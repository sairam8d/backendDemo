package com.spring.villagereport.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="villagelist")
public class Villagelist {
	@Id
	@GeneratedValue (strategy=GenerationType.IDENTITY)
	long id;
	
	@Column(name="name")
	String name;
	
	@Column(name="population")
	String population;
	
	@Column(name="age")
	String age;
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	public Villagelist(long id, String name, String population, String age) {
		super();
		this.id = id;
		this.name = name;
		this.population = population;
		this.age = age;
	}
	public Villagelist() {
		
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the population
	 */
	public String getPopulation() {
		return population;
	}
	/**
	 * @param population the population to set
	 */
	public void setPopulation(String population) {
		this.population = population;
	}
	/**
	 * @return the age
	 */
	public String getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(String age) {
		this.age = age;
	}
	
	

}
