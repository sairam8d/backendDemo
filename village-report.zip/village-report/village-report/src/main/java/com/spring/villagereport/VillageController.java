package com.spring.villagereport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.villagereport.model.Villagelist;


@RestController 
@RequestMapping("/village/")
@CrossOrigin(origins="http://localhost:4200")

public class VillageController {
	@Autowired
	private VillageRepository VillageRepository;
	
	@GetMapping("/villagelist")
	public List<Villagelist>allvillagedata() {
		return VillageRepository.findAll();
	}

	@PostMapping("/saveVllgdata")
	public Villagelist saveVillagedata(@RequestBody Villagelist vgList ) {
		return VillageRepository.save(vgList);

}
	
}
