package com.spring.villagereport;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.villagereport.model.Villagelist;

public interface VillageRepository extends JpaRepository<Villagelist,Long>{

}
