package com.spring.villagereport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VillageReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
